from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request, "board/index.html")
    # return HttpResponse("<h1>웹 메인 페이지 입니다.</h1>")

def question_list(request):
    return render(request, 'board/question_list.html')